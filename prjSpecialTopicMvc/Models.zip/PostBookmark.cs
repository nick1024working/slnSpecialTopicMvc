﻿using System;
using System.Collections.Generic;

namespace prjSpecialTopicMvc.Models;

public partial class PostBookmark
{
    public int BookmarkId { get; set; }

    public int PostId { get; set; }

    public Guid Uid { get; set; }

    public virtual ForumPost Post { get; set; } = null!;

    public virtual User UidNavigation { get; set; } = null!;
}
