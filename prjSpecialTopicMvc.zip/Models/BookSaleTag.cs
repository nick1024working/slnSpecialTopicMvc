﻿using System;
using System.Collections.Generic;

namespace prjSpecialTopicMvc.Models;

public partial class BookSaleTag
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public bool IsActive { get; set; }

    public int DisplayOrder { get; set; }

    public virtual ICollection<UsedBook> Books { get; set; } = new List<UsedBook>();
}
