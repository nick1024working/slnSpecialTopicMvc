﻿using System;
using System.Collections.Generic;

namespace prjSpecialTopicMvc.Models;

public partial class BookConditionDetail
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public virtual ICollection<UsedBook> Books { get; set; } = new List<UsedBook>();
}
